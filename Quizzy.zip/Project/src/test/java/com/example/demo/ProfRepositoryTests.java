package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;
 
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class ProfRepositoryTests {
	 @Autowired
	    private TestEntityManager entityManager;
	     
	    @Autowired
	    private ProfRepository repo;
	     
	    @Test
	    public void testCreateAdmin() {
	        Prof prof= new Prof();
	        prof.setEmail("p1@gmail.com");
	        prof.setPassword("p1");

	         
	        Prof savedProf = repo.save(prof);
	         
	        Prof existProf = entityManager.find(Prof.class, savedProf.getId());
	         
	        assertThat(prof.getEmail()).isEqualTo(existProf.getEmail());
	         
	    }

}

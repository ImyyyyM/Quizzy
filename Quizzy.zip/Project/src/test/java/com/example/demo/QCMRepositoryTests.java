package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashSet;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;
 
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class QCMRepositoryTests {
	 @Autowired
	    private TestEntityManager entityManager;
	     
	    @Autowired
	    private QCMRepository repo;
	     
	    @Test
	    public void testCreateQCM() {
	        QCM qcm= new QCM();
	        qcm.setQcmName("zzz");
	        qcm.setQcmduree(5);
	        HashSet<Student> s= new HashSet<Student>();
	        Student a= new Student();
	        s.add(a);
	        qcm.setStudents(s);
	        

	         
	        QCM savedQCM = repo.save(qcm);
	         
	        QCM existQCM = entityManager.find(QCM.class, savedQCM.getId());
	         
	        assertThat(qcm.getQcmName()).isEqualTo(existQCM.getQcmName());
	         
	    }

}

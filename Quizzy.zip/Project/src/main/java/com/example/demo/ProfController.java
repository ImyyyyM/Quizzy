package com.example.demo;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ProfController {
	QCM s;
	
	 @Autowired
	    private QCMRepository qcmRepo;
	 
	 
	 @Autowired
	    private QuestionRepository questRepo;
	 
	 
	 @Autowired
	    private ProfRepository ProfRepo;
	 
	
	    @GetMapping("/prof")
	    public String viewHomePage() {
	        return "profindex";
	    }
	    @GetMapping("/prof/newqcm/")
	    public String showProfRegistrationForm(Model model ) {
	    	Prof prof=new Prof("ppp", "p1", "p2", "p3");
		     model.addAttribute("qcm", new QCM());
		     model.addAttribute("prof", prof);
		     return "addqcm";
		     
	    }
	    
	    
	    
	    
	    
	    @PostMapping("/qcm_register")
	    public String processqcmRegister(QCM qcm, Prof prof) { 
	    	ProfRepo.save(prof);
	    	qcm.setProf(prof);
	        qcmRepo.save(qcm);
	        return "Student_register_success";
	    }
	   
	    
	    
	    @GetMapping("/prof/newquestion")
	    public String questionRegister(Model model) {
	    	 model.addAttribute("question", new Question());
		     return "addquestion";
	    	
	    }
	    
	    @PostMapping("/question_register")
	    public String processprofRegister(Question question) {
	        QCM qcm= new QCM("Q1", 12);
	        question.setQcm(qcm);
	    	questRepo.save(question);
	         
	        return "addquestion";
	    }
	    
	    @GetMapping("prof/qcms")
	    public String listqcms(Model model) {
	    	List<QCM> listqcms = qcmRepo.findAll();
	        model.addAttribute("listsqcms", listqcms);
	        return "qcmlist";
	        
	    }
	    
	    
	    @GetMapping("/prof/delete_qcm")
    	public String deleteqcm(@RequestParam Long ID) {
        	
    		qcmRepo.deleteById(ID);
    		
    		return "qcmlist";
    	}
        
        @GetMapping("/prof/update_qcm")
    	public ModelAndView updateProf(@RequestParam Long ID) {
        	ModelAndView mav = new ModelAndView("update-qcm-form");
    		QCM qcm = qcmRepo.findById(ID).get();
    		mav.addObject("qcm", qcm);
    		return mav;
    	}
	   
	    
	    
	    

}

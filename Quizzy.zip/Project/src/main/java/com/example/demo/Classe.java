
package com.example.demo;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "classes")

public class Classe {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
     
    @Column(nullable = false, unique = true, length = 45)
    private String Class_Name;
    
    @ManyToMany(fetch = FetchType.LAZY,
  	      cascade = {
  	          CascadeType.PERSIST,
  	          CascadeType.MERGE
  	      },
  	      mappedBy = "classes")
  @JsonIgnore
  private Set<Prof> profs = new HashSet<>();
    
    
    public Classe() {}
    public Classe(String Classe_Name) {
    	this.Class_Name=Class_Name;
    	
    }
    
    public Set<Prof> getProfs() {
		return profs;
	}
	public void setProfs(Set<Prof> profs) {
		this.profs = profs;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getClass_Name() {
		return Class_Name;
	}
	public void setClass_Name(String class_Name) {
		Class_Name = class_Name;
	}
	
    
    
     
    

}

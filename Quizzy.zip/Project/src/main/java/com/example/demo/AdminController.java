package com.example.demo;

import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

 
@Controller
public class AdminController {
	 @Autowired
	    private AdminRepository AdminRepo;
	
	 
	 @Autowired
	    private ClasseRepository ClassRepo;
	 
	 
	 @Autowired
	    private UerRepository UserRepo;
	 
	 @Autowired
	    private StudentRepository StudentRepo;
	 
	 @Autowired
	    private ProfRepository ProfRepo;
	 
	
	 @GetMapping("/")
	    public String HomePage() {
	        return "loginas";
	    }
	 
	 
	    @GetMapping("/admin")
	    public String viewHomePage() {
	        return "adminindex";
	    }
	    
	    @GetMapping("/admin/studentlist")
	    public String listStudents(Model model) {
	    	List<Student> listStudents = StudentRepo.findAll();
	    	model.addAttribute("listStudents", listStudents);
	        return "studentlist";
	    }
	    
	    @GetMapping("/admin/addstudent")
		 public String showRegistrationForm(Model model) {
		     model.addAttribute("student", new Student());   
		     return "AddStudent";
		 }
	    
	    @PostMapping("/student_register")
	    public String processstudentRegister(Student student) {
	    	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	    	String encodedPassword = encoder.encode(student.getPassword());
	        student.setPassword(encodedPassword);
	       
	    	StudentRepo.save(student);
	         
	        return "Student_register_success";
	    }
	    
	    
	   

        @GetMapping("/admin/delete_student")
    	public String deleteStudent(@RequestParam Long ID) {
        	
    		StudentRepo.deleteById(ID);
    		
    		return "studentlist";
    	}
        
        @GetMapping("/admin/update_student")
    	public ModelAndView updateStudent(@RequestParam Long ID) {
        	ModelAndView mav = new ModelAndView("update-student-form");
    		Student student = StudentRepo.findById(ID).get();
    		mav.addObject("student", student);
    		return mav;
    	}
	   
        
	    
	    @GetMapping("/admin/addpro")
		 public String showProfRegistrationForm(Model model) {
		     model.addAttribute("prof", new Prof());
		      
		     return "AddProf";
		 }
	    
	    @PostMapping("/prof_register")
	    public String processprofRegister(Prof prof) {
	    	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	    	String encodedPassword = encoder.encode(prof.getPassword());
	        prof.setPassword(encodedPassword);
	    	ProfRepo.save(prof);
	         
	        return "Prof_register_success";
	    }
	    
	    @GetMapping("/admin/proflist")
	    public String listUsers(Model model) {
	    	List<Prof> listProfs = ProfRepo.findAll();
	        model.addAttribute("listProfs", listProfs);
	        return "profslist";
	        
	    }
	    
	        @GetMapping("/admin/delete_prof")
	    	public String deleteProf(@RequestParam Long ID) {
	        	
	    		ProfRepo.deleteById(ID);
	    		
	    		return "profslist";
	    	}
	        
	        @GetMapping("/admin/update_prof")
	    	public ModelAndView updateProf(@RequestParam Long ID) {
	        	ModelAndView mav = new ModelAndView("update-prof-form");
	    		Prof prof = ProfRepo.findById(ID).get();
	    		mav.addObject("prof", prof);
	    		return mav;
	    	}

}
	  
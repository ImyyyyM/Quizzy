package com.example.demo;


import java.util.Date;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "qcms")

public class QCM {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
     
    @Column(name = "qcm", nullable = false, length = 20)
    private String qcmName;
    
    @Column(name = "result",  length = 20)
    private int result;
    
    
    @Column(name = "duree", nullable = false, length = 20)
    private int qcmduree;
    
    
    @ManyToMany(fetch = FetchType.LAZY,
  	      cascade = {
  	          CascadeType.PERSIST,
  	          CascadeType.MERGE
  	      },
  	      mappedBy = "qcms")
    @JsonIgnore
    private Set<Student> students = new HashSet<>();
  
  	
    
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "prof_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Prof prof;
    
    public QCM() {}
    
    public QCM(String qcmname, int qcmduree ) {
    	this.qcmName=qcmname;
   
    	this.qcmduree=qcmduree; 


    }
    
    
	public Set<Student> getStudents() {
		return students;
	}


	public void setStudents(Set<Student> students) {
		this.students = students;
	}


	public Prof getProf() {
		return prof;
	}


	public void setProf(Prof prof) {
		this.prof = prof;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public int getResult() {
		return result;
	}


	public void setResult(int result) {
		this.result = result;
	}


	public String getQcmName() {
		return qcmName;
	}


	public void setQcmName(String qcmName) {
		this.qcmName = qcmName;
	}


	

	public int getQcmduree() {
		return qcmduree;
	}


	public void setQcmduree(int qcmduree) {
		this.qcmduree = qcmduree;
	}

	
	

	


	


	
    
    
    
    	  

}



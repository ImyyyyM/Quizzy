package com.example.demo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
public interface ProfRepository extends JpaRepository<Prof, Long> {
	 @Query("SELECT u FROM Prof u WHERE u.email = ?1")
		Prof findByEmail(String email);
	}
	
	


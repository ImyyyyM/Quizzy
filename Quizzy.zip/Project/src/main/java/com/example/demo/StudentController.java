package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class StudentController {
	 @Autowired
	    private StudentRepository studentRepo;
	 
	 @Autowired
	    private QCMRepository qcmRepo;
	 
	 @Autowired
	    private QuestionRepository questRepo;
	 
	 
	
	 
	 @GetMapping("/student")
	    public String listQCMS(Model model) {
	    	List<QCM> listQCMs = qcmRepo.findAll();
	        return "studentindex";
	    }
	 
	 @GetMapping("/student/pass_qcm")
	    public String passqcm(Model model) {
	    	List<Question> listQuestions = questRepo.findAll();
	        model.addAttribute("listQuestions", listQuestions);
	        return "passqcm";
	        
     	
 		
 		
 		
 	}
	 
	 
	
}
